# AI Fake Post Detector

A Next.js web application powered by Perplexity AI that analyzes social media posts to determine their authenticity and help identify potential misinformation.

## Features

- 🤖 **AI-Powered Analysis**: Uses Perplexity AI's advanced language models to analyze post content
- 🎯 **Authenticity Detection**: Identifies potentially fake or misleading social media posts
- 📊 **Confidence Scoring**: Provides confidence levels for each analysis
- 🚨 **Risk Factor Identification**: Highlights specific concerns and red flags
- 💅 **Modern UI**: Beautiful, responsive design with Tailwind CSS
- ⚡ **Real-time Analysis**: Fast processing with loading states and error handling
- 🔒 **Secure API Integration**: Proper error handling and rate limiting

## Technology Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **Styling**: Tailwind CSS
- **AI Service**: Perplexity AI API
- **Icons**: Lucide React
- **HTTP Client**: Axios

## Getting Started

### Prerequisites

- Node.js 18.0 or later
- npm or yarn package manager
- Perplexity AI API key

### Installation

1. **Clone the repository** (or use the existing files):
   ```bash
   cd your-project-directory
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Set up environment variables**:
   Create a `.env.local` file in the root directory:
   ```env
   PERPLEXITY_API_KEY=your-perplexity-api-key-here
   NEXT_PUBLIC_APP_NAME=Fake Post Detector
   ```

4. **Get your Perplexity AI API key**:
   - Visit [Perplexity AI](https://www.perplexity.ai/)
   - Sign up for an account
   - Navigate to the API section
   - Generate your API key
   - Add it to your `.env.local` file

5. **Run the development server**:
   ```bash
   npm run dev
   ```

6. **Open your browser**:
   Navigate to [http://localhost:3000](http://localhost:3000) to see the application.

## Usage

1. **Enter Social Media Post**: Paste or type the social media post content you want to analyze
2. **Click Analyze**: Hit the "Analyze Post" button to start the AI analysis
3. **Review Results**: The application will display:
   - Whether the post appears genuine or potentially fake
   - Confidence level (0-100%)
   - Detailed explanation of the analysis
   - Specific risk factors identified

## API Endpoints

### POST `/api/analyze-post`

Analyzes a social media post for authenticity.

**Request Body:**
```json
{
  "postText": "The social media post content to analyze"
}
```

**Response:**
```json
{
  "isGenuine": true,
  "confidence": 0.85,
  "explanation": "Detailed analysis explanation...",
  "riskFactors": ["List of identified risk factors"]
}
```

**Error Response:**
```json
{
  "error": "Error type",
  "message": "Human-readable error message"
}
```

## Analysis Factors

The AI considers multiple factors when analyzing posts:

- **Factual Accuracy**: Verifiability of claims made
- **Emotional Manipulation**: Use of fear, anger, or urgency tactics
- **Source Credibility**: Indicators of reliable sources
- **Logical Consistency**: Internal logic and coherence
- **Language Patterns**: Grammar, style, and common misinformation markers
- **Viral Tactics**: Encouragement of sharing without verification
- **Conspiracy Indicators**: Language suggesting hidden agendas

## Project Structure

```
├── pages/
│   ├── api/
│   │   └── analyze-post.ts    # API endpoint for post analysis
│   ├── _app.tsx               # Next.js app component
│   └── index.tsx              # Main application page
├── styles/
│   └── globals.css            # Global styles with Tailwind
├── package.json               # Dependencies and scripts
├── next.config.js             # Next.js configuration
├── tsconfig.json              # TypeScript configuration
├── tailwind.config.js         # Tailwind CSS configuration
└── postcss.config.js          # PostCSS configuration
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `PERPLEXITY_API_KEY` | Your Perplexity AI API key | Yes |
| `NEXT_PUBLIC_APP_NAME` | Application name for branding | No |

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

### Adding New Features

1. **New Analysis Parameters**: Modify the prompt in `/pages/api/analyze-post.ts`
2. **UI Components**: Add new components in a `/components` directory
3. **Styling**: Customize Tailwind classes or add new CSS

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your repository to [Vercel](https://vercel.com)
3. Add your environment variables in the Vercel dashboard
4. Deploy automatically on every commit

### Other Platforms

The application can be deployed on any platform that supports Next.js:
- Netlify
- Railway
- AWS Amplify
- Google Cloud Platform
- DigitalOcean App Platform

## Rate Limiting & Costs

- Perplexity AI has rate limits on their API
- Monitor your usage to avoid unexpected costs
- Consider implementing client-side rate limiting for heavy usage

## Important Disclaimers

⚠️ **Educational Purpose**: This tool is designed for educational and awareness purposes.

⚠️ **Not 100% Accurate**: AI analysis is not infallible. Always verify information from multiple reliable sources.

⚠️ **Human Verification Required**: Use this tool as a starting point, not a definitive answer.

⚠️ **Context Matters**: The tool analyzes content in isolation and may miss important context.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is for educational purposes. Please respect Perplexity AI's terms of service when using their API.

## Support

If you encounter issues:

1. Check that your Perplexity AI API key is correctly configured
2. Verify all dependencies are installed
3. Check the browser console for error messages
4. Review the server logs for API-related issues

## Troubleshooting

### Common Issues

**"API key not configured" error:**
- Ensure your `.env.local` file exists and contains `PERPLEXITY_API_KEY`
- Restart the development server after adding environment variables

**TypeScript errors:**
- Run `npm install` to ensure all dependencies are installed
- Check that all required packages are in `package.json`

**Styling issues:**
- Ensure Tailwind CSS is properly configured
- Check that `globals.css` includes Tailwind directives

**API request failures:**
- Verify your Perplexity AI API key is valid
- Check your internet connection
- Monitor rate limits and usage quotas

---

Made with ❤️ using Next.js and Perplexity AI 