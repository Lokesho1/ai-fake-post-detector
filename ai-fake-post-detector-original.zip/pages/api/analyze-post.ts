import type { NextApiRequest, NextApiResponse } from 'next/api';
import axios from 'axios';

interface AnalysisResult {
  isGenuine: boolean;
  confidence: number;
  explanation: string;
  riskFactors: string[];
}

interface ErrorResponse {
  error: string;
  message: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<AnalysisResult | ErrorResponse>
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed', message: 'Only POST requests are accepted' });
  }

  const { postText } = req.body;

  if (!postText || typeof postText !== 'string' || postText.trim().length === 0) {
    return res.status(400).json({ error: 'Invalid input', message: 'Post text is required and must be a non-empty string' });
  }

  const apiKey = process.env.PERPLEXITY_API_KEY;
  if (!apiKey) {
    console.error('PERPLEXITY_API_KEY is not configured');
    return res.status(500).json({ error: 'Server configuration error', message: 'API key not configured' });
  }

  try {
    const prompt = `You are an expert in detecting fake news and misinformation on social media. Analyze the following social media post for authenticity and potential misinformation.

Post content: "${postText}"

Please provide a detailed analysis covering:
1. Whether the post appears to be genuine or potentially fake/misleading
2. Your confidence level (0-1) in this assessment
3. Specific reasoning for your assessment
4. Any red flags or risk factors you identified

Format your response as a JSON object with these exact keys:
- isGenuine: boolean (true if likely genuine, false if potentially fake)
- confidence: number (0-1, where 1 is completely confident)
- explanation: string (detailed reasoning for your assessment)
- riskFactors: array of strings (specific concerns or red flags found)

Consider factors like:
- Factual accuracy and verifiability
- Emotional manipulation tactics
- Source credibility indicators
- Logical consistency
- Common misinformation patterns
- Grammar and language patterns
- Urgency or fear-mongering language
- Claims that seem too good/bad to be true

Respond only with the JSON object, no additional text.`;

    const response = await axios.post(
      'https://api.perplexity.ai/chat/completions',
      {
        model: 'llama-3.1-sonar-small-128k-online',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful assistant that analyzes social media posts for authenticity. Always respond with valid JSON only.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 1000,
        temperature: 0.2,
        top_p: 0.9,
        return_citations: true,
        search_domain_filter: ['perplexity.ai'],
        return_images: false,
        return_related_questions: false,
        search_recency_filter: 'month',
        top_k: 0,
        stream: false,
        presence_penalty: 0,
        frequency_penalty: 1
      },
      {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: 30000, // 30 seconds timeout
      }
    );

    const aiResponse = response.data.choices[0]?.message?.content;
    
    if (!aiResponse) {
      throw new Error('No response received from AI');
    }

    // Try to parse the JSON response
    let analysisResult: AnalysisResult;
    try {
      // Clean the response in case there's any extra text
      const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? jsonMatch[0] : aiResponse;
      analysisResult = JSON.parse(jsonString);
    } catch (parseError) {
      console.error('Failed to parse AI response as JSON:', parseError);
      console.error('AI Response:', aiResponse);
      
      // Fallback: create a manual analysis based on basic patterns
      const riskFactors = [];
      const lowerText = postText.toLowerCase();
      
      // Check for common fake news indicators
      if (lowerText.includes('breaking:') || lowerText.includes('urgent:')) {
        riskFactors.push('Uses urgency tactics');
      }
      if (lowerText.includes('100%') || lowerText.includes('guaranteed')) {
        riskFactors.push('Makes absolute claims');
      }
      if (lowerText.includes('they don\'t want you to know')) {
        riskFactors.push('Uses conspiracy language');
      }
      if (lowerText.includes('share if') || lowerText.includes('repost')) {
        riskFactors.push('Encourages viral sharing');
      }
      
      analysisResult = {
        isGenuine: riskFactors.length === 0,
        confidence: riskFactors.length === 0 ? 0.7 : 0.3,
        explanation: `Analysis completed with basic pattern detection. ${riskFactors.length > 0 ? 'Several risk factors were identified.' : 'No obvious risk factors detected, but manual verification recommended.'}`,
        riskFactors: riskFactors.length > 0 ? riskFactors : ['Unable to perform detailed AI analysis - please verify from multiple sources']
      };
    }

    // Validate the structure of the analysis result
    if (typeof analysisResult.isGenuine !== 'boolean' ||
        typeof analysisResult.confidence !== 'number' ||
        typeof analysisResult.explanation !== 'string' ||
        !Array.isArray(analysisResult.riskFactors)) {
      throw new Error('Invalid analysis result structure');
    }

    // Ensure confidence is between 0 and 1
    analysisResult.confidence = Math.max(0, Math.min(1, analysisResult.confidence));

    return res.status(200).json(analysisResult);

  } catch (error) {
    console.error('Error analyzing post:', error);
    
    if (axios.isAxiosError(error)) {
      if (error.response?.status === 401) {
        return res.status(500).json({ error: 'Authentication failed', message: 'Invalid API key or authentication error' });
      } else if (error.response?.status === 429) {
        return res.status(429).json({ error: 'Rate limit exceeded', message: 'Too many requests. Please try again later.' });
      } else if (error.code === 'ECONNABORTED') {
        return res.status(408).json({ error: 'Request timeout', message: 'The analysis request timed out. Please try again.' });
      }
    }

    return res.status(500).json({ 
      error: 'Analysis failed', 
      message: 'An unexpected error occurred while analyzing the post. Please try again later.' 
    });
  }
} 