import React, { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle, Loader2, Send } from 'lucide-react';

interface AnalysisResult {
  isGenuine: boolean;
  confidence: number;
  explanation: string;
  riskFactors: string[];
}

export default function Home() {
  const [postText, setPostText] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const analyzePost = async () => {
    if (!postText.trim()) {
      setError('Please enter a social media post to analyze');
      return;
    }

    setAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/analyze-post', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ postText }),
      });

      if (!response.ok) {
        throw new Error('Failed to analyze post');
      }

      const data = await response.json();
      setResult(data);
    } catch (error) {
      setError('An error occurred while analyzing the post. Please try again.');
      console.error('Analysis error:', error);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Shield className="mx-auto h-16 w-16 text-indigo-600 mb-4" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            AI Fake Post Detector
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Powered by Perplexity AI, our advanced system analyzes social media posts 
            to determine their authenticity and help you identify potential misinformation.
          </p>
        </div>

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Input Section */}
          <div className="mb-8">
            <label htmlFor="post-text" className="block text-lg font-medium text-gray-700 mb-3">
              Enter Social Media Post
            </label>
            <textarea
              id="post-text"
              rows={6}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
              placeholder="Paste the social media post content here..."
              value={postText}
              onChange={(e) => setPostText(e.target.value)}
            />
          </div>

          {/* Analyze Button */}
          <div className="text-center mb-8">
            <button
              onClick={analyzePost}
              disabled={analyzing || !postText.trim()}
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {analyzing ? (
                <>
                  <Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Send className="-ml-1 mr-3 h-5 w-5" />
                  Analyze Post
                </>
              )}
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex">
                <AlertTriangle className="h-5 w-5 text-red-400 mr-2 mt-0.5" />
                <p className="text-red-700">{error}</p>
              </div>
            </div>
          )}

          {/* Results Section */}
          {result && (
            <div className="mt-8 p-6 bg-gray-50 rounded-xl">
              <div className="flex items-center mb-4">
                {result.isGenuine ? (
                  <CheckCircle className="h-8 w-8 text-green-500 mr-3" />
                ) : (
                  <AlertTriangle className="h-8 w-8 text-red-500 mr-3" />
                )}
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">
                    {result.isGenuine ? 'Likely Genuine' : 'Potentially Fake'}
                  </h3>
                  <p className="text-gray-600">
                    Confidence: {Math.round(result.confidence * 100)}%
                  </p>
                </div>
              </div>

              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Analysis:</h4>
                <p className="text-gray-700">{result.explanation}</p>
              </div>

              {result.riskFactors && result.riskFactors.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Risk Factors:</h4>
                  <ul className="list-disc list-inside text-gray-700 space-y-1">
                    {result.riskFactors.map((factor, index) => (
                      <li key={index}>{factor}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-500">
          <p>
            This AI analysis is for educational purposes. Always verify information 
            from multiple sources before making decisions.
          </p>
        </div>
      </div>
    </div>
  );
} 