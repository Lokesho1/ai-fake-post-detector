import React from 'react'

export default function Home() {
  return (
    <main className="container">
      <div className="hello-world">
        <h1>HELLO WORLD!</h1>
      </div>
    </main>
  );
} 